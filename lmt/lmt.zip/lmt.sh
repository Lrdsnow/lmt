#!/bin/bash

dist=""
pkg=""
ru="N"
mcgp=""
mcgpn=""
ver="v0"
cver=""
distc=""
urda=""
pkgver=$pkg"ver"
dpkgver=$pkgver".txt"

check_dist() {
  distc="$(awk '/^ID=/' /etc/*-release | awk -F'=' '{ print tolower($2) }')"
  if [[ $distc = "ubuntu" ]]; then
    dist="u"
  elif [[ $distc = "alpine" ]]; then
    dist="a"
  fi
}

print_usage() {
  printf "Usage:\n Flags:\n -a: alpine linux\n -u: ubuntu linux\n Commands:\n -i <app>: installs app"
}

mcginstall() {
  if [[ -d ~/.lmt ]]; then
    mkdir ~/.lmt/pkgs/$pkg
  else
    mkdir ~/.lmt
    mkdir ~/.lmt/pkgs
    mkdir ~/.lmt/pkgs/$pkg
  fi
  wget "https://raw.githubusercontent.com/Lrdsnow/lmt/main/$pkg/$pkg.zip" -O ~/$pkg.zip
  unzip ~/$pkg.zip -d ~/.lmt/pkgs/$pkg/
  pkgver=$pkg"ver"
  dpkgver=$pkgver".txt"
  wget "https://raw.githubusercontent.com/Lrdsnow/lmt/main/$pkg/$dpkgver" -O ~/.lmt/pkgs/$pkg/version.txt
  if [[ $pkg = "lmt-gui" ]]; then
    touch ~/$pkg && echo "cd ~/.lmt/pkgs/$pkg && python3 ~/.lmt/pkgs/$pkg/main.py" > ~/$pkg && sudo chmod 755 ~/$pkg && sudo mv ~/$pkg /bin/$pkg
  else
    touch ~/$pkg && echo "~/.lmt/pkgs/$pkg/./$pkg.sh" > ~/$pkg && sudo chmod 755 ~/$pkg && sudo mv ~/$pkg /bin/$pkg && sudo chmod 755 ~/.lmt/pkgs/$pkg/$pkg".sh"
  fi
  pkgver="$(grep -o 'v[^"]*' ~/.lmt/pkgs/$pkg/version.txt)"
  echo "Succsessfuly Installed $pkg.$pkgver"
}

install() {
  if [[ $dist = "u" ]]
  then
    if [[ $ru = "N" ]]
    then
      sudo apt install -y $pkg
    elif [[ $ru = "Y" ]]
    then
      apt install -y $pkg
    else
      echo "Error"
    fi
  elif [[ $dist = "a" ]]
  then
    if [[ $ru = "N" ]]
    then
      sudo apk add $pkg
    elif [[ $ru = "Y" ]]
    then
      apk add $pkg
    else
      echo "Error"
    fi
  else
    printf "No Distro Selected\n"
  fi
}

preinstall() {
  #printf "$pkg\n"
  if [[ $urda = "Y" ]];  then
    install
  else
    mcginstall
  fi
}

gui() {
  gui=~/.lmt/pkgs/lmt-gui/main.py
  if [[ -f "$gui" ]]; then
    lmt-gui
  else
    echo 'GUI Is Not installed Please Install It With "lmt -i lmt-gui"'
  fi
}

check_dist
while getopts 'guari:' flag; do
  case "${flag}" in
    a) dist="a" && urda="Y";;
    u) dist="u" && urda="Y";;
    i) pkg=$OPTARG && preinstall;;
    r) ru="Y";;
    g) gui;;
    *) print_usage
       exit 1 ;;
  esac
done
